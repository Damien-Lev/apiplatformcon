create materialized view v_classement_saison as
SELECT j.id,
       j.pseudo,
       e.id             AS equipe_id,
       sum(rp.points)   AS points,
       sum(
               CASE
                   WHEN rp.place = 1 THEN 1
                   ELSE 0
                   END) AS nb_top1,
       sum(
               CASE
                   WHEN rp.place >= 1 AND rp.place <= 4 THEN 1
                   ELSE 0
                   END) AS nb_top4
FROM saison s
         JOIN manche m ON m.saison_id = s.id
         JOIN partie p ON p.manche_id = m.id
         JOIN lobby l ON l.partie_id = p.id
         JOIN resultat_partie rp ON rp.lobby_id = l.id
         JOIN joueur j ON rp.joueur_id = j.id
         JOIN equipe e ON j.equipe_id = e.id
GROUP BY j.id, j.pseudo, e.id
ORDER BY (sum(rp.points)) DESC,
         (sum(
                 CASE
                     WHEN rp.place = 1 THEN 1
                     ELSE 0
                     END)) DESC,
         (sum(
                 CASE
                     WHEN rp.place >= 1 AND rp.place <= 4 THEN 1
                     ELSE 0
                     END)) DESC;

alter materialized view v_classement_saison owner to apiplatformcon;

create unique index idx_v_classement_saison
    on v_classement_saison (id);

