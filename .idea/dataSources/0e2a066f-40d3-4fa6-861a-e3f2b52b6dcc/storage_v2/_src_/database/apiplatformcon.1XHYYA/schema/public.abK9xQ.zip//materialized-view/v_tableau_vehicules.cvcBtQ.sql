create materialized view v_tableau_vehicules as
SELECT v.id,
       v.state,
       v.car,
       v.vin,
       ca.id                                                                               AS categorie_id,
       ca.code                                                                             AS categorie_code,
       co.id                                                                               AS concession_id,
       co.code_interne                                                                     AS concession_code_interne,
       co.libelle_affichage                                                                AS concession_libelle_affichage,
       co.adresse                                                                          AS concession_adresse,
       co.ville                                                                            AS concession_ville,
       co.code_postal                                                                      AS concession_code_postal,
       reg.id                                                                              AS region_id,
       reg.libelle                                                                         AS region_libelle,
       ma.id                                                                               AS marque_id,
       ma.code                                                                             AS marque_code,
       ma.libelle                                                                          AS marque_libelle,
       CASE
           WHEN sum(o.id) = 0 THEN '[]'::text
           ELSE ('[{"'::text || string_agg((o.code::text || '":"'::text) || o.libelle::text, '"},{"'::text)) || '"}]'::text
           END                                                                             AS options,
       sc.id                                                                               AS suivi_commande_id,
       to_char(sc.date_commande::timestamp with time zone,
               'dd/mm/yyyy'::text)                                                         AS suivi_commande_date_commande,
       to_char(sc.date_reception_commande::timestamp with time zone,
               'dd/mm/yyyy'::text)                                                         AS suivi_commande_date_reception_commande,
       to_char(sc.date_debut_construction::timestamp with time zone,
               'dd/mm/yyyy'::text)                                                         AS suivi_commande_date_debut_construction,
       to_char(sc.date_fin_construction::timestamp with time zone,
               'dd/mm/yyyy'::text)                                                         AS suivi_commande_date_fin_construction,
       to_char(sc.date_depart_usine::timestamp with time zone,
               'dd/mm/yyyy'::text)                                                         AS suivi_commande_date_depart_usine,
       to_char(sc.date_reception_concession::timestamp with time zone,
               'dd/mm/yyyy'::text)                                                         AS suivi_commande_date_reception_concession,
       res.id                                                                              AS reservation_id,
       to_char(res.date_demande::timestamp with time zone, 'dd/mm/yyyy'::text)             AS reservation_date_demande,
       cl.id                                                                               AS client_id,
       cl.nom                                                                              AS client_nom,
       cl.prenom                                                                           AS client_prenom,
       cl.adresse                                                                          AS client_adresse,
       cl.code_postal                                                                      AS client_code_postal,
       cl.ville                                                                            AS client_ville,
       cl.telephone                                                                        AS client_telephone,
       cl.email                                                                            AS client_email,
       mo.id                                                                               AS modele_id,
       mo.libelle                                                                          AS modele_libelle
FROM vehicule v
         JOIN categorie ca ON v.categorie_id = ca.id
         JOIN concession co ON v.concession_id = co.id
         JOIN region reg ON co.region_id = reg.id
         JOIN marque ma ON v.marque_id = ma.id
         JOIN suivi_commande sc ON v.suivi_commande_id = sc.id
         JOIN modele mo ON v.modele_id = mo.id
         LEFT JOIN vehicule_option vo ON vo.vehicule_id = v.id
         LEFT JOIN option o ON vo.option_id = o.id
         LEFT JOIN reservation res ON res.vehicule_id = v.id AND res.en_cours = true
         LEFT JOIN client cl ON res.client_id = cl.id
GROUP BY v.id, ca.id, ca.code, co.id, co.code_interne, co.libelle_affichage, co.adresse, co.ville, co.code_postal,
         reg.id, reg.libelle, ma.id, ma.code, ma.libelle, sc.id, sc.date_commande, sc.date_reception_commande,
         sc.date_debut_construction, sc.date_fin_construction, sc.date_depart_usine, sc.date_reception_concession,
         res.id, res.date_demande, cl.id, cl.nom, cl.prenom, cl.adresse, cl.code_postal, cl.ville, cl.telephone,
         cl.email, v.state, v.car, v.vin, mo.id, mo.libelle;

alter materialized view v_tableau_vehicules owner to apiplatformcon;

create unique index uniq_v_tableau_vehicules
    on v_tableau_vehicules (id);

