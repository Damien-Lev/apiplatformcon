create materialized view v_compteurs as
WITH somme AS (SELECT sum(
                              CASE
                                  WHEN v.state::text = 'en_commande'::text THEN 1
                                  ELSE 0
                                  END) AS en_commande,
                      sum(
                              CASE
                                  WHEN v.state::text = 'en_stock'::text THEN 1
                                  ELSE 0
                                  END) AS en_stock,
                      sum(
                              CASE
                                  WHEN v.state::text = 'reserve'::text THEN 1
                                  ELSE 0
                                  END) AS reserve,
                      sum(
                              CASE
                                  WHEN v.state::text = 'vendu'::text THEN 1
                                  ELSE 0
                                  END) AS vendu
               FROM vehicule v),
     compteurs AS (SELECT compteurs.name
                   FROM (VALUES ('en_commande'::text),
                                ('en_stock'::text),
                                ('reserve'::text),
                                ('vendu'::text)) compteurs(name))
SELECT c.name,
       CASE
           WHEN c.name = 'en_commande'::text THEN COALESCE(somme.en_commande, 0::bigint)
           WHEN c.name = 'en_stock'::text THEN COALESCE(somme.en_stock, 0::bigint)
           WHEN c.name = 'reserve'::text THEN COALESCE(somme.reserve, 0::bigint)
           WHEN c.name = 'vendu'::text THEN COALESCE(somme.vendu, 0::bigint)
           ELSE 0::bigint
           END AS value
FROM compteurs c,
     somme;

alter materialized view v_compteurs owner to apiplatformcon;

create unique index uniq_v_compteurs
    on v_compteurs (name);

