create materialized view v_meilleures_ventes_options as
SELECT agrregate.region_id,
       agrregate.option_id,
       agrregate.option_code,
       agrregate.option_libelle,
       agrregate.somme,
       agrregate.rank
FROM (SELECT r.id                                                        AS region_id,
             o.id                                                        AS option_id,
             o.code                                                      AS option_code,
             o.libelle                                                   AS option_libelle,
             count(o.id)                                                 AS somme,
             rank() OVER (PARTITION BY r.id ORDER BY (count(o.id)) DESC) AS rank
      FROM vehicule v
               JOIN concession c ON v.concession_id = c.id
               JOIN region r ON c.region_id = r.id
               JOIN vehicule_option vo ON vo.vehicule_id = v.id
               JOIN option o ON vo.option_id = o.id
      WHERE v.state::text = 'vendu'::text
      GROUP BY r.id, o.id, o.code, o.libelle) agrregate
WHERE agrregate.rank <= 3;

alter materialized view v_meilleures_ventes_options owner to apiplatformcon;

create unique index uniq_v_meilleures_ventes_options
    on v_meilleures_ventes_options (region_id, option_id);

